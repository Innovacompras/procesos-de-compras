<?php

/*
Plugin Name: Procesos de Compras
Plugin URI: https://www.dgcp.gob.do/instituciones-implementadas/
Description: Muestra los detalles de los procesos de compra gestionados a través del Sistema Electrónico de Contrataciones Públicas (SECP) - Portal Transaccional.
Version: 0.1.5
Author: Dirección General de Contrataciones Públicas por Edward Ceballos Camacho
Author URI: https://www.edwardceballos.com
*/

define('PROCESS_DIR', plugin_dir_path(__FILE__));

require_once( PROCESS_DIR . 'processes_class.php' );

function processes_settings_init() {
	register_setting( 'processes', 'processes_options' );

	add_settings_section(
		'processes_section',
		__( 'Configuración para mostrar detalles de los Procesos de Compra', 'processes' ), 'processes_section_callback',
		'processes'
	);

	add_settings_field(
		'codigo_uc',
		__( 'Código de Unidad de Compras (UC)', 'processes' ),
		'add_processes_setings_text',
		'processes',
		'processes_section',
		array(
			'label_for'         => 'codigo_uc',
			'class'             => 'processes_row',
			'processes_custom_data' => '000007',
			'type' => 'text',
			'description' => 'Si no sabe cual es su código de unidad de compra o puede consultarlo en el enlace <a href="https://www.dgcp.gob.do/instituciones-implementadas/" target="_blank">https://www.dgcp.gob.do/instituciones-implementadas/</a>.',
		)
	);

	add_settings_field(
		'text_color',
		__( 'Color para títulos', 'processes' ),
		'add_processes_setings_text',
		'processes',
		'processes_section',
		array(
			'label_for'         => 'text_color',
			'class'             => 'processes_row',
			'processes_custom_data' => '#1761c3',
			'type' => 'color',
			'description' => '',
		)
	);

	add_settings_field(
		'text_color2',
		__( 'Color para títulos (Franja blanca)', 'processes' ),
		'add_processes_setings_text',
		'processes',
		'processes_section',
		array(
			'label_for'         => 'text_color2',
			'class'             => 'processes_row',
			'processes_custom_data' => '#1761c3',
			'type' => 'color',
			'description' => '',
		)
	);

	add_settings_field(
		'bg_color',
		__( 'Color para fondo de los títulos', 'processes' ),
		'add_processes_setings_text',
		'processes',
		'processes_section',
		array(
			'label_for'         => 'bg_color',
			'class'             => 'processes_row',
			'processes_custom_data' => '#e1f1ff',
			'type' => 'color',
			'description' => '',
		)
	);

	add_settings_field(
		'button_color',
		__( 'Color para el botón', 'processes' ),
		'add_processes_setings_text',
		'processes',
		'processes_section',
		array(
			'label_for'         => 'button_color',
			'class'             => 'processes_row',
			'processes_custom_data' => '#1761c4',
			'type' => 'color',
			'description' => '',
		)
	);

	add_settings_field(
		'font',
			__( 'Incluir FontAwesome 5.3.0', 'processes' ),
		'add_processes_setings',
		'processes',
		'processes_section',
		array(
			'label_for'         => 'font',
			'class'             => 'processes_row',
			'processes_custom_data' => '1',
			'description' => '',
		)
	);

	add_settings_field(
		'css',
			__( 'Incluir modulo de Bootstrap 4 4.6.2', 'processes' ),
		'add_processes_setings',
		'processes',
		'processes_section',
		array(
			'label_for'         => 'css',
			'class'             => 'processes_row',
			'processes_custom_data' => '1',
			'description' => '',
		)
	);
}

add_action( 'admin_init', 'processes_settings_init' );

function processes_section_callback( $args ) {
	?>
	<div  id="<?php echo esc_attr( $args['id'] ); ?>">
		<p>Para incluir los detalles de sus procesos de compra copie y pegue el siguiente fragmento de código en la página deseada:</p>
		<textarea style="background:#fff; border:none; resize:none;" onfocus="this.select();" readonly rows="1">[list_processes]</textarea>
	</div>
	<?php
}

function add_processes_setings_text( $args ) {
	$options = get_option( 'processes_options' );
	?>

	<input
		id="<?php echo esc_attr( $args['label_for'] ); ?>"
		data-custom="<?php echo esc_attr( $args['processes_custom_data'] ); ?>"
		name="processes_options[<?php echo esc_attr( $args['label_for'] ); ?>]"
		type="<?php echo esc_attr( $args['type'] ); ?>"
		value="<?php echo isset( $options[ $args['label_for'] ] ) ? ( $options[ $args['label_for'] ] ) : ( $args['processes_custom_data'] ); ?>"
		style="min-width: 200px; max-width: 100%;" />

	<p class="description"><?php echo ( $args['description'] ); ?></p>
	<?php
}

function add_processes_setings( $args ) {
	$options = get_option( 'processes_options' );
	?>
	<select
			style="min-width: 200px; max-width: 100%;"
			id="<?php echo esc_attr( $args['label_for'] ); ?>"
			data-custom="<?php echo esc_attr( $args['processes_custom_data'] ); ?>"
			name="processes_options[<?php echo esc_attr( $args['label_for'] ); ?>]">

		<option value="1" <?php echo isset( $options[ $args['label_for'] ] ) ? ( selected( $options[ $args['label_for'] ], '1', false ) ) : ( '' ); ?>>
			<?php esc_html_e( 'Sí', 'processes' ); ?>
		</option>

 		<option value="0" <?php echo isset( $options[ $args['label_for'] ] ) ? ( selected( $options[ $args['label_for'] ], '0', false ) ) : ( '' ); ?>>
			<?php esc_html_e( 'No', 'processes' ); ?>
		</option>

	</select>

	<p class="description"><?php echo ( $args['description'] ); ?></p>
	<?php
}

function processes_options_page() {
	add_menu_page(
		'Configuración Procesos de Compra',
		'Configuración Procesos de Compra',
		'manage_options',
		'processes',
		'processes_options_page_html',
		'dashicons-index-card'
	);
}

add_action( 'admin_menu', 'processes_options_page' );

function processes_options_page_html() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	if ( isset( $_GET['settings-updated'] ) ) {
		add_settings_error( 'processes_messages', 'processes_message', __( 'Configuración Guardada', 'processes' ), 'updated' );
	}

	settings_errors( 'processes_messages' );
	?>
	<div class="wrap">
		<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
		<form action="options.php" method="post">
			<?php
			settings_fields( 'processes' );
			do_settings_sections( 'processes' );
			submit_button( 'Guardar Configuración' );
			?>
		</form>
	</div>
	<?php
}

// Hook para sobreescribir la respuesta de actualización
add_filter('pre_set_site_transient_update_plugins', 'procesos_check_for_update');
function procesos_check_for_update($transient) {
    if (empty($transient->checked)) return $transient;

    $remote = wp_remote_get('https://raw.githubusercontent.com/Innovacompras/procesos-de-compras/refs/heads/main/wordpress/updates.json');
    if (is_wp_error($remote) || wp_remote_retrieve_response_code($remote) != 200) return $transient;

    $remote_data = json_decode(wp_remote_retrieve_body($remote));

    $plugin_file = 'procesos-de-compras/procesos_de_compras.php'; // ← Ruta relativa correcta
    $current_version = $transient->checked[$plugin_file];

    if (version_compare($remote_data->version, $current_version, '>')) {
        $transient->response[$plugin_file] = (object) [
            'slug'        => 'procesos-de-compras',
            'plugin'      => $plugin_file,
            'new_version' => $remote_data->version,
            'tested'      => $remote_data->tested,
            'package'     => $remote_data->download_url,
            'url'         => $remote_data->homepage,
        ];
    }

    return $transient;
}

// Muestra información del plugin en el popup de "Ver detalles"
add_filter('plugins_api', 'procesos_api_info', 20, 3);
function procesos_api_info($res, $action, $args) {
    if ($args->slug !== 'procesos-de-compras') return $res;

    $remote = wp_remote_get('https://raw.githubusercontent.com/Innovacompras/procesos-de-compras/refs/heads/main/wordpress/updates.json');
    if (is_wp_error($remote) || wp_remote_retrieve_response_code($remote) != 200) return $res;

    $remote_data = json_decode(wp_remote_retrieve_body($remote));

    return (object) [
        'name'           => $remote_data->name,
        'slug'           => 'procesos-de-compras',
        'version'        => $remote_data->version,
        'author'         => $remote_data->author,
        'download_link'  => $remote_data->download_url,
        'requires'       => $remote_data->requires,
        'tested'         => $remote_data->tested,
        'homepage'       => $remote_data->homepage,
        'sections'       => (array) $remote_data->sections,
        'banners'        => (array) $remote_data->banners,
  		'icons'          => (array) $remote_data->icons
    ];
}

add_shortcode( 'list_processes', 'getProcessesData');
