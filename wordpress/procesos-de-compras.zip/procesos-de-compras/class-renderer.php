<?php

class DGCP_Renderer {
    private $data;

    public function __construct($info) {
        $this->data = $info['payload']['content'] ?? [];
    }

    public function render() {

        $html = '';

        $options = get_option( 'processes_options' );
        if ($options) {
            $codigo = $options['codigo_uc'] ? esc_attr( $options['codigo_uc']) : "000007";
            $color_bg = $options['color_bg'] ? esc_attr( $options['color_bg']) : "#e1f1ff";
            $color_text = $options['color_text'] ? esc_attr( $options['color_text']) : "#1761c3";
            $color_text2 = $options['color_text2'] ? esc_attr( $options['color_text2']) : "#1761c3";
            $color_buttom = $options['color_buttom'] ? esc_attr( $options['color_buttom']) : "#1761c4";
            $html .= '<style>
                #accordionP{
                    font-size: 14px;
                }

                #accordionP a.hover {
                    cursor: pointer;
                }

                #accordionP a.hover:hover {
                    text-decoration: none;
                }

                #accordionP .card {
                    border: 0;
                    border: 1px solid '.$color_bg.';
                    border-radius: 0
                }

                #accordionP .card-header {
                    border: 0;
                    border-radius: 0;
                    background: '.$color_bg.';
                    padding: 0 .5rem
                }

                #accordionP .card-title {
                    text-align: center;
                    color: #1662c2
                }

                #accordionP .card-header .text-blue a {
                    display: block;
                    width: 95%;
                    padding: .75rem .75rem;
                    position: relative;
                    font-weight: bold;
                    color: '.$color_text.';
                }

                #accordionP .card-header .text-blue a.collapsed:after {
                    position: absolute;
                    color: '.$color_text.';
                    font-family: "Font Awesome 5 Free";
                    font-style: normal;
                    font-weight: 900;
                    font-size: 14px;
                    content: "\f067";
                    right: calc(-5%);
                    top: 50%;
                    transform: translate(0, -50%);
                    background-color: transparent !important;
                }

                #accordionP .card-header .text-blue a:after {
                    position: absolute;
                    color: '.$color_text.';
                    font-family: "Font Awesome 5 Free";
                    font-style: normal;
                    font-weight: 900;
                    font-size: 14px;
                    content: "\f068";
                    right: calc(-5%);
                    top: 50%;
                    transform: translate(0, -50%);
                    background-color: transparent;
                }

                #accordionP .card:nth-child(even)>.card-header {
                    background-color: #fff;
                }
                #accordionP .card:nth-child(even)>.card-header a,
                #accordionP .card:nth-child(even)>.card-header .text-blue a:after {
                    color: '.$color_text2.';
                }

                #accordionP .card-body {
                    padding: .5rem;
                    font-weight: 300;
                    line-height: 1.7
                }

                #accordionP .jumbotron {
                    background: #f6f7f7;
                    padding: 1.5rem;
                    margin-top: .5rem;
                    margin-bottom: 0;
                    border-radius: 0
                }
                #accordionP .archivos .right {
                    border-right: 2px solid #d0d1d3;
                    padding-right: 10px;
                    text-align: right
                }

                #accordionP .archivos .left {
                    padding-left: 10px
                }

                #accordionP .archivos b {
                    color: #666
                }
                #accordionP .btn-primary{
                    font-size: 1rem;
                    font-weight: bold;
                    width: 100%;
                    padding: 0.5rem;
                    background-color: '.$color_buttom.';
                    border:  '.$color_buttom.';
                    -webkit-transition: all .25s ease;
                    -moz-transition: all .25s ease;
                    -ms-transition: all .25s ease;
                    -o-transition: all .25s ease;
                    transition: all .25s ease;
                }
                #accordionP .btn-primary:hover{
                    transform: scale(1.05);
                }

            </style>';
        }

        $html .= '<div class="accordion processes" id="accordionP">';

        foreach ($this->data as $modalidad => $anios) {
            $modalidad_id = $this->slugify($modalidad);

            $html .= $this->cardStart($modalidad_id, $modalidad, 'accordionP');

            // Ordenar años descendente
            krsort($anios);
            foreach ($anios as $anio => $meses) {
                $anio_id = $modalidad_id . '-' . $anio;
                $html .= $this->cardStart($anio_id, $anio, 'collapse-' . $modalidad_id);

                // Ordenar meses en orden descendente personalizado
                uksort($meses, [$this, 'compareMonths']);

                foreach ($meses as $mes => $procesos) {
                    $mes_id = $anio_id . '-' . $this->slugify($mes);
                    $html .= $this->cardStart($mes_id, $mes, 'collapse-' . $anio_id);

                    // Si es Excepción, hay tipos
                    if ($modalidad === 'Casos de Excepción') {
                        foreach ($procesos as $tipo => $subprocesos) {
                            $tipo_id = $mes_id . '-' . $this->slugify($tipo);
                            $html .= $this->cardStart($tipo_id, $tipo, 'collapse-' . $mes_id);

                            foreach ($subprocesos as $subproceso) {
                                $html .= $this->renderProceso($subproceso);
                            }

                            $html .= $this->cardEnd(); // tipo
                        }
                    } else {
                        // Modalidades normales
                        foreach ($procesos as $proceso) {
                            $html .= $this->renderProceso($proceso);
                        }
                    }

                    $html .= $this->cardEnd(); // mes
                }

                $html .= $this->cardEnd(); // año
            }

            $html .= $this->cardEnd(); // modalidad
        }

        $html .= '</div>';
        return $html;
    }

    private function renderProceso($proceso) {

        $date = new DateTime($proceso['fecha_publicacion']);

        // Set the locale to Spanish for the desired format
        $formatter = new IntlDateFormatter(
            'es_ES', // Locale
            IntlDateFormatter::FULL, // Date type
            IntlDateFormatter::NONE, // Time type
            null, // Timezone
            IntlDateFormatter::GREGORIAN, // Calendar type
            "EEEE, d 'de' MMMM 'de' yyyy" // Pattern
        );

        // Format the date
        $date_output = $formatter->format($date);

        $html = '<div class="jumbotron archivos">';
        $html .= '<div class="row align-items-center">';
        $html .= '<div class="col">';
        $html .= '<h6><a class="text-dark" href="'.$proceso['url'].'" title="Ver" target="_blank">'.htmlspecialchars($proceso['codigo_proceso']).'</a></h6>';
        $html .= '<p class="mb-0 bold">' . htmlspecialchars($proceso['descripcion']) . '</p>';
        $html .= '<p class="mb-0" style="font-size: .85rem"><strong title="Estado del Proceso"><i class="fas fa-spinner"></i></strong> ' . htmlspecialchars($proceso['estado_proceso']) . '</p>';
        $html .= '<p class="mb-0" style="font-size: .85rem"><strong title="Fecha de Publicación"><i class="fas fa-calendar-alt"></i></strong> Publicado el ' . $date_output . '</p>';
        $html .= '</div><div class="col-3 mt-md-0">';
        $html .= '<a class="btn btn-primary btn-lg d-none d-md-block" href="' . $proceso['url'] . '" target="_blank" title="Detalles"><i class="fas fa-link"></i> DETALLES</a>';
        $html .= '<a class="btn btn-primary btn-lg d-block d-md-none" href="' . $proceso['url'] . '" target="_blank" title="Detalles"><i class="fas fa-2x fa-link"></i></a>';
        $html .= '</div>';
        $html .= '</div>';
        $html .= '</div>';
        return $html;
    }

    private function cardStart($id, $title, $parent_id) {

        $options = get_option( 'processes_options' );
        if ($options) {
            $css = $options['css'] ? esc_attr( $options['css']) : "0";
        }
                
        $collapse_id = 'collapse-' . $id;
        return '
        <div class="card">
            <div class="card-header parents" id="heading-' . $id . '">
                <p class="title text-blue mb-0">
                    <a class="btn-block hover text-left collapsed" ' . ($css === "2" ? 'data-bs-toggle':'data-toggle') .'="collapse" ' . ($css === "2" ? 'data-bs-target':'data-target') .'="#' . $collapse_id . '" aria-expanded="false" aria-controls="' . $collapse_id . '">' . htmlspecialchars($title) . '</a>
                </p>
            </div>
            <div id="' . $collapse_id . '" class="collapse" aria-labelledby="heading-' . $id . '" data-parent="#' . $parent_id . '">
                <div class="card-body">';
    }

    private function cardEnd() {
        return '</div></div></div>';
    }

    private function slugify($text) {
        return strtolower(trim(preg_replace('/[^A-Za-z0-9]+/', '-', $text)));
    }

    private function compareMonths($a, $b) {
        $months = [
            "Enero" => 1, "Febrero" => 2, "Marzo" => 3, "Abril" => 4,
            "Mayo" => 5, "Junio" => 6, "Julio" => 7, "Agosto" => 8,
            "Septiembre" => 9, "Octubre" => 10, "Noviembre" => 11, "Diciembre" => 12
        ];

        return ($months[$a] ?? 0) < ($months[$b] ?? 0) ? 1 : -1;
    }
}
