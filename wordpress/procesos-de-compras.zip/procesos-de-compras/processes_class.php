<?php

setlocale(LC_ALL,"es_ES");

require_once plugin_dir_path(__FILE__) . 'class-renderer.php';


if (!function_exists("fetchData")) {
	function fetchData($url, $bearerToken = null){
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_TIMEOUT, 20);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_HTTPHEADER, [
		    "Authorization: Bearer $bearerToken", // Enviar el token en el encabezado
		    "Content-Type: application/json" // Especificar el tipo de contenido si es JSON
		]);
		$result = curl_exec($ch);
		curl_close($ch);
		return $result;
	}
}

function enqueue_processes() {

	$options = get_option( 'processes_options' );
	$font = @$options['font'];
	$css = @$options['css'];

	if ($css) {
		wp_enqueue_style('bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css' );

		wp_enqueue_script('jquery', 'https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js', array(), false, true );
		wp_enqueue_script('bootstrap-js', 'https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js', array(), false, true );
	}

	if ($font) {
		wp_enqueue_style('fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.3.0/css/solid.min.css' );
	}

}

add_action('wp_footer', 'enqueue_processes');


if (!function_exists("getProcessesData")) {
	function getProcessesData($atts, $innerCall = false) {

		$options = get_option( 'processes_options' );

		$codigo_uc = isset($atts['codigo_uc']) ? $atts['codigo_uc'] : esc_attr( $options['codigo_uc']);

		$data = processes_obtener_datos_api($codigo_uc);

		if ($data) {

			$dgcp = new DGCP_Renderer($data, $atts);
			$impre = $dgcp->render();

			$impre .= '<p class="pt-2 small">* Está página se actualiza cada día por parte de la <a href="https://www.dgcp.gob.do/" target="_blank">Dirección General de Contrataciones Públicas (DGCP)</a>.</p>';
			return $impre;
		}else{
			return "<strong>Esta institución no ha publicado procesos de compra en el Sistema Electrónico de Contrataciones Públicas (SECP).</strong>";
		}
		return false;

	}
}

function processes_cache_valido($path) {
    if (!file_exists($path)) return false;

    $mod = filemtime($path);
    $now = time();
    $today = date('Y-m-d');
    $horas = ['07:30', '14:30', '21:30']; // Horas de actualización

    // Encuentra la última hora clave que ya pasó hoy
    foreach (array_reverse($horas) as $h) {
        $ts = strtotime("$today $h");
        if ($now >= $ts) return $mod >= $ts;
    }

    // Si ninguna hora clave ha pasado hoy, compara con la última de ayer
    return $mod >= strtotime('-1 day ' . end($horas));
}

function processes_obtener_datos_api($codigo_uc) {

	$cache_path = plugin_dir_path(__FILE__) . 'cache/';

	if ($codigo_uc) {

		if ( ! file_exists($cache_path) ){
			mkdir($cache_path, 0775);
		}

		$file = $cache_path.$codigo_uc.'.json';

	    // Si el cache aún es válido, lo usamos
		if (processes_cache_valido($file)) {
			$json = file_get_contents($file);
			$data = json_decode($json, true, 512, JSON_BIGINT_AS_STRING);

			if ($data) {
				if (isset($data['payload']['content'])) {
					return $data;
				}
			}
		}

	    // De lo contrario, consultamos la API
		$urlSync = 'https://datosabiertos.dgcp.gob.do/api-dgcp/v1/procesos/agrupados?unidad_compra='.intval($codigo_uc);

		$data = fetchData($urlSync);

		if (!$data) {
	        return "Error al obtener los datos."; // o puedes retornar un cache viejo si deseas
	    }

	    // Guarda el contenido como cache
	    file_put_contents($file, $data);

	    return json_decode($data, true, 512, JSON_BIGINT_AS_STRING);
	}
	else{
		return 'Tiene que ingresar un código de unidad de compra.';
	}
}
