<?php

setlocale(LC_ALL,"es_ES");

require_once plugin_dir_path(__FILE__) . 'class-renderer.php';


if (!function_exists("fetchData")) {
	function fetchData($url, $bearerToken = null){
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_TIMEOUT, 20);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_HTTPHEADER, [
		    "Authorization: Bearer $bearerToken", // Enviar el token en el encabezado
		    "Content-Type: application/json" // Especificar el tipo de contenido si es JSON
		]);
		$result = curl_exec($ch);
		curl_close($ch);
		return $result;
	}
}

function enqueue_processes() {

	$options = get_option( 'processes_options' );
	$font = @$options['font'];
	$css = @$options['css'];
	
	if ($css) {
		wp_enqueue_script('jquery', 'https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js', array(), false, true );
		if ($css === "2"){
			// bootstrap CSS desde CDN 521
			wp_enqueue_style('bootstrap-521-stylesheet-cdn', "https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css", array(), null, 'all');
			wp_enqueue_script('bootstrap-521-script-cdn', "https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js", array('jquery'), null, true);
		}
		if ($css === "1"){
			wp_enqueue_style('bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css' );
			wp_enqueue_script('bootstrap-js', 'https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js', array(), false, true );
		}

	}

	if ($font) {
		wp_enqueue_style('fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.3.0/css/solid.min.css' );
	}

}

add_action('wp_footer', 'enqueue_processes');


if (!function_exists("getProcessesData")) {
	function getProcessesData() {

		$data = mi_plugin_obtener_datos_api();

		if ($data) {

			$dgcp = new DGCP_Renderer($data);
			$impre = $dgcp->render();

			$impre .= '<p class="pt-2 small">* Está página se actualiza cada día por parte de la <a href="https://www.dgcp.gob.do/" target="_blank">Dirección General de Contrataciones Públicas (DGCP)</a>.</p>';
			return $impre;
		}else{
			return "<strong>Esta institución no ha publicado procesos de compra en el Sistema Electrónico de Contrataciones Públicas (SECP).</strong>";
		}
		return false;

	}
}

function mi_plugin_get_cache_path() {
	return plugin_dir_path(__FILE__) . 'cache/data.json';
}

function mi_plugin_cache_valido($path, $horas = 3) {
	return file_exists($path) && (time() - filemtime($path) < $horas * 3600);
}

function mi_plugin_obtener_datos_api() {
	$cache_path = mi_plugin_get_cache_path();

    // Si el cache aún es válido, lo usamos
	if (mi_plugin_cache_valido($cache_path)) {
		$json = file_get_contents($cache_path);
		$data = json_decode($json, true, 512, JSON_BIGINT_AS_STRING);

		if ($data) {
			if (isset($data['payload']['content'])) {
				return $data;
			}
		}
	}

	$options = get_option( 'processes_options' );
	if ($options) {
		$codigo = $options['codigo_uc'] ? esc_attr( $options['codigo_uc']) : "000007";
	    // De lo contrario, consultamos la API
		$urlSync = 'https://datosabiertos.dgcp.gob.do/api-dgcp/v1/procesos/agrupados?unidad_compra='.intval($codigo);

		$data = fetchData($urlSync);


		if (!$data) {
	        return null; // o puedes retornar un cache viejo si deseas
	    }

	    // Guarda el contenido como cache
	    file_put_contents($cache_path, $data);

	    return json_decode($data, true, 512, JSON_BIGINT_AS_STRING);
	}
}
