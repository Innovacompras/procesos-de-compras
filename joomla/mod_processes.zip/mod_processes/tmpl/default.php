<?php

$codigo = isset($params['codigo_uc']) ? $params['codigo_uc'] : "000007";
$color_bg = isset($params['color_bg']) ? $params['color_bg'] : "#e1f1ff";
$color_text = isset($params['color_text']) ? $params['color_text'] : "#1761c3";
$color_buttom = isset($params['color_buttom']) ? $params['color_buttom'] : "#1761c4";
$font = isset($params['font']) ? $params['font'] : true;
$css = isset($params['css']) ? $params['css'] : true;

?>
<?php if ($css): ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>
<?php endif ?>

<?php if ($font): ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<?php endif ?>

<style>
    #accordionP{
        font-size: 14px;
    }

    #accordionP a.hover {
        cursor: pointer;
    }

    #accordionP a.hover:hover {
        text-decoration: none;
    }

    #accordionP .card {
        border: 0;
        border: 1px solid <?php echo $color_bg; ?>;
        border-radius: 0
    }

    #accordionP .card-header {
        border: 0;
        border-radius: 0;
        background: <?php echo $color_bg; ?>;
        padding: 0 .5rem
    }

    #accordionP .card-title {
        text-align: center;
        color: #1662c2
    }

    #accordionP .card-header .text-blue a {
        display: block;
        width: 95%;
        padding: .75rem .75rem .75rem 0;
        position: relative;
        font-weight: bold;
        color: <?php echo $color_text; ?>;
    }

    #accordionP .card-header .text-blue a.collapsed:after {
        position: absolute;
        color: <?php echo $color_text; ?>;
        font-family: 'Font Awesome 5 Free';
        font-style: normal;
        font-weight: 700;
        font-size: 14px;
        content: "\f067";
        right: calc(-6% - 10px);
        top: 50%;
        transform: translate(0, -50%);
        background-color: transparent !important;
    }

    #accordionP .card-header .text-blue a:after {
        position: absolute;
        color: <?php echo $color_text; ?>;
        font-family: 'Font Awesome 5 Free';
        font-style: normal;
        font-weight: 700;
        font-size: 14px;
        content: "\f068";
        right: calc(-6% - 10px);
        top: 50%;
        transform: translate(0, -50%);
        background-color: transparent;
    }

    #accordionP .card:nth-child(even)>.card-header {
        background-color: #fff
    }

    #accordionP .card-body {
        padding: .5rem 0 .5rem .5rem;
        font-weight: 300;
        line-height: 1.7
    }

    #accordionP .jumbotron {
        background: #f6f7f7;
        padding: 1.5rem;
        margin-top: .5rem;
        margin-bottom: 0;
        border-radius: 0
    }
    #accordionP .archivos .right {
        border-right: 2px solid #d0d1d3;
        padding-right: 10px;
        text-align: right
    }

    #accordionP .archivos .left {
        padding-left: 10px
    }

    #accordionP .archivos b {
        color: #666
    }
    #accordionP .btn-primary{
        font-size: 1rem;
        font-weight: bold;
        width: 100%;
        padding: 0.5rem;
        background-color: <?php echo $color_buttom; ?>;
        border:  <?php echo $color_buttom; ?>;
        -webkit-transition: all .25s ease;
        -moz-transition: all .25s ease;
        -ms-transition: all .25s ease;
        -o-transition: all .25s ease;
        transition: all .25s ease;
    }
    #accordionP .btn-primary:hover{
        transform: scale(1.05);
    }

</style>

<?php
require 'functions.php';

echo(getProcessesData($codigo));
