<?php

setlocale(LC_ALL,"es_ES");
require 'class_renderer.php';

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;

if (!function_exists("fetchData")) {
	function fetchData($url, $bearerToken = null){
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_TIMEOUT, 20);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_HTTPHEADER, [
		    "Authorization: Bearer $bearerToken", // Enviar el token en el encabezado
		    "Content-Type: application/json" // Especificar el tipo de contenido si es JSON
		]);
		$result = curl_exec($ch);
		curl_close($ch);
		return $result;
	}
}

if (!function_exists("getProcessesData")) {
	function getProcessesData($codigo_uc = 0) {

		$data = processes_obtener_datos_api($codigo_uc);

		if ($data) {

			$dgcp = new DGCP_Renderer($data);
			$impre = $dgcp->render();

			$impre .= '<p class="pt-2 small">* Está página se actualiza cada día por parte de la <a href="https://www.dgcp.gob.do/" target="_blank">Dirección General de Contrataciones Públicas (DGCP)</a>.</p>';
			return $impre;

		}else{
			return "<strong>Esta institución no ha publicado procesos de compra en el Sistema Electrónico de Contrataciones Públicas (SECP).</strong>";
		}
		return false;
	}
}

function processes_get_cache_path() {
	return JPATH_SITE . '/modules/mod_processes/cache/data.json';
}

function processes_cache_valido($path) {
    if (!file_exists($path)) return false;

    $mod = filemtime($path);
    $now = time();
    $today = date('Y-m-d');
    $horas = ['07:30', '14:30', '21:30']; // Horas de actualización

    // Encuentra la última hora clave que ya pasó hoy
    foreach (array_reverse($horas) as $h) {
        $ts = strtotime("$today $h");
        if ($now >= $ts) return $mod >= $ts;
    }

    // Si ninguna hora clave ha pasado hoy, compara con la última de ayer
    return $mod >= strtotime('-1 day ' . end($horas));
}

function processes_obtener_datos_api($codigo_uc = 0) {
	$cache_path = processes_get_cache_path();

    // Si el cache aún es válido, lo usamos
	if (processes_cache_valido($cache_path)) {
		$json = file_get_contents($cache_path);
		$data = json_decode($json, true, 512, JSON_BIGINT_AS_STRING);

		if ($data) {
			if (isset($data['payload']['content'])) {
				return $data;
			}
		}
	}


    // De lo contrario, consultamos la API
	$urlSync = 'https://datosabiertos.dgcp.gob.do/api-dgcp/v1/procesos/agrupados?unidad_compra='.intval($codigo_uc);

	$data = fetchData($urlSync);


	if (!$data) {
        return null; // o puedes retornar un cache viejo si deseas
    }

    // Guarda el contenido como cache
    file_put_contents($cache_path, $data);

    return json_decode($data, true, 512, JSON_BIGINT_AS_STRING);

}