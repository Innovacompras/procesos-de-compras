<?php

setlocale(LC_ALL,"es_ES");


use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;

if (!function_exists("fetchData")) {
	function fetchData($url){
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_TIMEOUT, 20);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		$result = curl_exec($ch);
		curl_close($ch);
		return $result;
	}
}

if (!function_exists("getProcessesData")) {
	function getProcessesData($codigo_uc = 0) {

		$urlSync = 'https://api.dgcp.gob.do/opendata/transparencia/'.$codigo_uc.'.json';
		$data = json_decode(fetchData($urlSync), true, 512, JSON_BIGINT_AS_STRING);

		$impre = '';
		if ($data) {

			$impre .= listProcesses($data);
			$impre .= '<p class="pt-2 small">* Está página se actualiza cada día a las 8:00 a.m. por parte de la <a href="https://www.dgcp.gob.do/" target="_blank">Dirección General de Contrataciones Públicas (DGCP)</a>.</p>';
			return $impre;
		}else{
			return "<strong>Esta institución no ha publicado procesos de compra en el Sistema Electrónico de Contrataciones Públicas (SECP).</strong>";
		}
		return false;

	}
}

if (!function_exists("listProcesses")) {
	function listProcesses($data = array(),
		$folderIndex = 0, $impre = '') {

		global $folderIndex;


		$container_id = "accordionP".$folderIndex;

		$impre .= '<div class="accordion processes" id="'.$container_id .'">';

		$i = 1;

		foreach($data as $key => $value){

			$folderIndex++;
			$i++;
			$unid = uniqid();
			$impre .= '<div class="card" id="'.$unid.'">';

			if(is_array($key)) {
				$impre .= '<div class="card-header parents" id="heading'.$folderIndex.'">';
			} else {
				$impre .= '<div class="card-header" id="heading'.$folderIndex.'">';
			}

			$impre .= '<p class="title text-blue mb-0 mr-1">';

			$dataParent = 'data-parent="#'.$container_id.'"';

			$impre .= '<a class="btn-block hover text-left collapsed" data-toggle="collapse" data-target="#collapse'.$folderIndex.'" aria-expanded="true" aria-controls="collapse'.$folderIndex.'">';

			if(is_array($data[$key])) {

				$impre .= strip_tags($key);

			} else {

				$impre .= strip_tags($value);

			}

			$impre .= '</a>';

			$impre .= '</p>';

			$impre .= '</div>';

			$impre .= '<div id="collapse'.$folderIndex.'" class="collapse" aria-labelledby="heading'.$folderIndex.'" '. $dataParent .'>';

			$impre .= '<div class="card-body">';


			if(is_array($data[$key]) && !isset($data[$key][0]['URL'])) {

				$impre .= listProcesses($data[$key], $folderIndex);

			} else {

				$arr3 = $data[$key];

				if ($arr3) {
					$arr3 = array_reverse($arr3);
					foreach ($arr3 as $key2 => $value3) {

						$date_input = (strftime("%A, %d de %B de %Y", strtotime(substr($value3['FechaPublicacion'], 0, -10) )));


						$url = $value3['URL'];
						$impre .= '<h6 class="pt-3"><a class="text-dark" href="'.($url).'" title="Ver" target="_blank">'.$value3['CodigoProceso'].'</a></h6>
						<div class="jumbotron archivos">
						<div class="row align-items-center">
						<div class="col">
						<a class="text-dark" href="'.($url).'" title="Ver" target="_blank">
						<b>'.$value3['Descripcion'].'</b><br>';

						// if ($value3['CertificadoApropiacionPresupuestaria']) {
						// 	for($i = 0; $i < count($value3['CertificadoApropiacionPresupuestaria']); $i++){
						// 		$impre .= '<p class="mb-0"><a class="" href="'.($value3['CertificadoApropiacionPresupuestaria'][$i]).'" title="Ver" target="_blank"> Apropiación Presupuestaría '.($i+1).'</a></p>';
						// 	}
						// }

						// if ($value3['CertificadoDisponibilidadCuotaComprometer']) {
						// 	for($i = 0; $i < count($value3['CertificadoDisponibilidadCuotaComprometer']); $i++){
						// 		$impre .= '<p class="mb-0"><a class="" href="'.($value3['CertificadoDisponibilidadCuotaComprometer'][$i]).'" title="Ver" target="_blank">Cuota de Compromiso '.($i+1).'</a></p>';
						// 	}
						// }

						$impre .= '<span style="font-size: .85rem" title="Estado del Proceso"><i class="fas fa-spinner"></i> '.$value3['EstadoProceso'].'
							<br><span style="font-size: .85rem" title="Fecha de Publicación"><i class="fas fa-calendar-alt"></i> Publicado el '.$date_input.'</span>
						</a>
						</div>
						<div class="col-3  mt-md-0">
						<a href="'.($url).'" class="btn btn-primary btn-lg d-none d-md-block" title="Detalles" target="_blank"><i class="fas fa-link"></i> DETALLES</a>
						<a href="'.($url).'" class="btn btn-primary btn-lg d-block d-md-none" title="Detalles" target="_blank"><i class="fas fa-2x fa-link"></i></a>
						</div>
						</div>
						</div>';

					}

				}
			}

			$impre .= '</div>';

			$impre .= '</div>';

			$impre .= '</div>';

		}

		$impre .= '</div>';

		return $impre;
	}
}