<?php

class DGCP_Renderer {
    private $data;

    public function __construct($info) {
        $this->data = $info['payload']['content'] ?? [];
    }

    public function render() {

        $html = '<div class="accordion processes" id="accordionP">';

        foreach ($this->data as $modalidad => $anios) {
            $modalidad_id = $this->slugify($modalidad);

            $html .= $this->cardStart($modalidad_id, $modalidad, 'accordionP');

            // Ordenar años descendente
            krsort($anios);
            foreach ($anios as $anio => $meses) {
                $anio_id = $modalidad_id . '-' . $anio;
                $html .= $this->cardStart($anio_id, $anio, 'collapse-' . $modalidad_id);

                // Ordenar meses en orden descendente personalizado
                uksort($meses, [$this, 'compareMonths']);

                foreach ($meses as $mes => $procesos) {
                    $mes_id = $anio_id . '-' . $this->slugify($mes);
                    $html .= $this->cardStart($mes_id, $mes, 'collapse-' . $anio_id);

                    // Si es Excepción, hay tipos
                    if ($modalidad === 'Casos de Excepción') {
                        foreach ($procesos as $tipo => $subprocesos) {
                            $tipo_id = $mes_id . '-' . $this->slugify($tipo);
                            $html .= $this->cardStart($tipo_id, $tipo, 'collapse-' . $mes_id);

                            foreach ($subprocesos as $subproceso) {
                                $html .= $this->renderProceso($subproceso);
                            }

                            $html .= $this->cardEnd(); // tipo
                        }
                    } else {
                        // Modalidades normales
                        foreach ($procesos as $proceso) {
                            $html .= $this->renderProceso($proceso);
                        }
                    }

                    $html .= $this->cardEnd(); // mes
                }

                $html .= $this->cardEnd(); // año
            }

            $html .= $this->cardEnd(); // modalidad
        }

        $html .= '</div>';
        return $html;
    }

    private function renderProceso($proceso) {

        $date = new DateTime($proceso['fecha_publicacion']);

        // Set the locale to Spanish for the desired format
        $formatter = new IntlDateFormatter(
            'es_ES', // Locale
            IntlDateFormatter::FULL, // Date type
            IntlDateFormatter::NONE, // Time type
            null, // Timezone
            IntlDateFormatter::GREGORIAN, // Calendar type
            "EEEE, d 'de' MMMM 'de' yyyy" // Pattern
        );

        // Format the date
        $date_output = $formatter->format($date);

        $html = '<div class="jumbotron archivos">';
        $html .= '<div class="row align-items-center">';
        $html .= '<div class="col">';
        $html .= '<h6><a class="text-dark" href="'.$proceso['url'].'" title="Ver" target="_blank">'.htmlspecialchars($proceso['codigo_proceso']).'</a></h6>';
        $html .= '<p class="mb-0 bold">' . htmlspecialchars($proceso['descripcion']) . '</p>';
        $html .= '<p class="mb-0" style="font-size: .85rem"><strong title="Estado del Proceso"><i class="fas fa-spinner"></i></strong> ' . htmlspecialchars($proceso['estado_proceso']) . '</p>';
        $html .= '<p class="mb-0" style="font-size: .85rem"><strong title="Fecha de Publicación"><i class="fas fa-calendar-alt"></i></strong> Publicado el ' . $date_output . '</p>';
        $html .= '</div><div class="col-3 mt-md-0">';
        $html .= '<a class="btn btn-primary btn-lg d-none d-md-block" href="' . $proceso['url'] . '" target="_blank" title="Detalles"><i class="fas fa-link"></i> DETALLES</a>';
        $html .= '<a class="btn btn-primary btn-lg d-block d-md-none" href="' . $proceso['url'] . '" target="_blank" title="Detalles"><i class="fas fa-2x fa-link"></i></a>';
        $html .= '</div>';
        $html .= '</div>';
        $html .= '</div>';
        return $html;
    }

    private function cardStart($id, $title, $parent_id) {
        $collapse_id = 'collapse-' . $id;
        return '
        <div class="card">
            <div class="card-header parents" id="heading-' . $id . '">


                <p class="title text-blue mb-0">
                    <a class="btn-block hover text-left collapsed" data-toggle="collapse" data-target="#' . $collapse_id . '" aria-expanded="false" aria-controls="' . $collapse_id . '">' . htmlspecialchars($title) . '</a>
                </p>
            </div>
            <div id="' . $collapse_id . '" class="collapse" aria-labelledby="heading-' . $id . '" data-parent="#' . $parent_id . '">
                <div class="card-body">';
    }

    private function cardEnd() {
        return '</div></div></div>';
    }

    private function slugify($text) {
        return strtolower(trim(preg_replace('/[^A-Za-z0-9]+/', '-', $text)));
    }

    private function compareMonths($a, $b) {
        $months = [
            "Enero" => 1, "Febrero" => 2, "Marzo" => 3, "Abril" => 4,
            "Mayo" => 5, "Junio" => 6, "Julio" => 7, "Agosto" => 8,
            "Septiembre" => 9, "Octubre" => 10, "Noviembre" => 11, "Diciembre" => 12
        ];

        return ($months[$a] ?? 0) < ($months[$b] ?? 0) ? 1 : -1;
    }
}
