<?php

// No direct access
defined('_JEXEC') or die;
 
$doc = JFactory::getDocument();
$modBaseUrl = Juri::base() . 'modules/mod_processes';

require JModuleHelper::getLayoutPath('mod_processes');