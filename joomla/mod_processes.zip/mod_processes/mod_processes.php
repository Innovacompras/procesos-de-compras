<?php

// No direct access
defined('_JEXEC') or die;
 
$doc = JFactory::getDocument();
$modBaseUrl = Juri::base() . 'modules/mod_processes';

// $doc->addStyleSheet($modBaseUrl . '/assets/jquery.fancybox.min.css' );
// $doc->addScript($modBaseUrl . '/assets/jquery.fancybox.min.js' );

require JModuleHelper::getLayoutPath('mod_processes');